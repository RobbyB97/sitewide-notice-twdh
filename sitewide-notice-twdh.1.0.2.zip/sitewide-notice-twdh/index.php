<?php
    // Silence is golden.
